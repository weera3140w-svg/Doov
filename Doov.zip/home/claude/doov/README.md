# 🎬 Doov — Video Sharing Platform

เว็บแชร์วิดีโอสำหรับชุมชน Discord ของคุณ

## ฟีเจอร์ทั้งหมด
- ✅ สมัครบัญชี / เข้าสู่ระบบ
- ✅ อัพโหลดวิดีโอ (สูงสุด 500MB)
- ✅ รูปโปรไฟล์รองรับ GIF
- ✅ ภาพปกวิดีโอ (รองรับ GIF)
- ✅ ระบบเรตติ้ง (ทุกวัย / 13+ / 15+ / 18+)
- ✅ Age Gate สำหรับ 18+ (ใส่วันเกิดทุกครั้ง)
- ✅ จำกัดผู้ชม (สาธารณะ / เฉพาะผู้ติดตาม / ส่วนตัว)
- ✅ กดถูกใจ + ดูวิดีโอที่ถูกใจ
- ✅ คอมเมนต์
- ✅ ติดตามช่อง
- ✅ ค้นหาวิดีโอ
- ✅ รายงานวิดีโอ
- ✅ แชร์วิดีโอ (Discord + Native Share)
- ✅ ดาวน์โหลดวิดีโอ
- ✅ รองรับภาษาไทย-อังกฤษ
- ✅ รองรับมือถือ (Responsive)

## การติดตั้ง

### 1. ติดตั้ง Node.js
ดาวน์โหลดจาก https://nodejs.org (แนะนำ v18+)

### 2. ติดตั้ง dependencies
```bash
cd Doov
npm install
```

### 3. ตั้งค่า .env
```bash
# เปลี่ยนชื่อ env.txt เป็น .env
mv env.txt .env
# แก้ไข SESSION_SECRET ให้เป็นค่าสุ่มยาวๆ
```

### 4. รันเว็บ
```bash
npm start
```
เปิดเบราว์เซอร์ที่ http://localhost:3000

## Deploy บน Railway (ให้คนอื่นเข้าได้)

1. สร้างบัญชีที่ https://railway.app
2. กด "New Project" → "Deploy from GitHub"
3. Push โค้ดขึ้น GitHub ก่อน แล้ว connect
4. เพิ่ม Environment Variables:
   - `SESSION_SECRET` = ข้อความสุ่มยาวๆ เช่น `my_super_secret_2024_xyz`
5. Railway จะ deploy อัตโนมัติ ได้ URL มาแชร์เลย!

## โครงสร้างไฟล์
```
Doov/
├── server.js          ← Backend (Node.js + Express)
├── package.json
├── env.txt            ← เปลี่ยนเป็น .env ก่อนรัน
├── doov.db            ← ฐานข้อมูล (สร้างอัตโนมัติ)
└── public/
    ├── index.html     ← Frontend ทั้งหมด
    └── uploads/
        ├── avatars/
        ├── videos/
        └── thumbnails/
```
